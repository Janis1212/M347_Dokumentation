public class DatabaseSettings
{
    public string ConnectionString { get; set; } = "";
}